'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { BuyResult } from '@deriv/core';
import type { ClosedPosition, Direction } from '@/lib/types';

type BotStatus = 'idle' | 'buying' | 'waiting' | 'stopped';

interface MartingaleBotPanelProps {
  isAuthenticated: boolean;
  isConnected: boolean;
  activeSymbolName?: string;
  duration: number;
  durationUnit: string;
  setStake: (value: string) => void;
  buyContract: (direction?: Direction, amountOverride?: number) => Promise<BuyResult | null>;
  isBuying: boolean;
  closedPositions: ClosedPosition[];
  refreshClosedPositions: () => Promise<void>;
}

function toNumber(value: number | string | null | undefined): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function roundMoney(value: number): number {
  return Math.round(value * 100) / 100;
}

function getPositionProfit(position: ClosedPosition): number {
  return roundMoney(toNumber(position.sell_price) - toNumber(position.buy_price));
}

export function MartingaleBotPanel({
  isAuthenticated,
  isConnected,
  activeSymbolName,
  duration,
  durationUnit,
  setStake,
  buyContract,
  isBuying,
  closedPositions,
  refreshClosedPositions,
}: MartingaleBotPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [status, setStatus] = useState<BotStatus>('idle');
  const [direction, setDirection] = useState<Direction>('CALL');
  const [initialStake, setInitialStake] = useState('1');
  const [multiplier, setMultiplier] = useState('2');
  const [maxStake, setMaxStake] = useState('50');
  const [profitTarget, setProfitTarget] = useState('5');
  const [lossLimit, setLossLimit] = useState('2');
  const [currentStake, setCurrentStake] = useState(1);
  const [totalProfit, setTotalProfit] = useState(0);
  const [lastContractId, setLastContractId] = useState<number | null>(null);
  const [message, setMessage] = useState('Bot is off.');

  const isRunningRef = useRef(false);
  const currentStakeRef = useRef(1);
  const handledContractIdsRef = useRef<Set<number>>(new Set());

  const canStart = isAuthenticated && isConnected && !isBuying && durationUnit === 't';

  const parsedSettings = useMemo(() => {
    const baseStake = Number(initialStake);
    const size = Number(multiplier);
    const max = Number(maxStake);
    const target = Number(profitTarget);
    const loss = Number(lossLimit);

    return {
      baseStake: Number.isFinite(baseStake) && baseStake > 0 ? baseStake : 1,
      size: Number.isFinite(size) && size > 1 ? size : 2,
      max: Number.isFinite(max) && max > 0 ? max : 50,
      target: Number.isFinite(target) && target > 0 ? target : 5,
      loss: Number.isFinite(loss) && loss > 0 ? loss : 2,
    };
  }, [initialStake, multiplier, maxStake, profitTarget, lossLimit]);

  const stopBot = useCallback((nextMessage = 'Bot stopped.') => {
    isRunningRef.current = false;
    setIsRunning(false);
    setStatus('stopped');
    setLastContractId(null);
    setMessage(nextMessage);
  }, []);

  const placeTrade = useCallback(async (stakeAmount: number) => {
    if (!isRunningRef.current) return;

    setStatus('buying');
    setMessage(`Buying ${direction === 'PUT' ? 'Fall' : 'Rise'} with stake ${stakeAmount.toFixed(2)} USD...`);
    setCurrentStake(stakeAmount);
    currentStakeRef.current = stakeAmount;
    setStake(stakeAmount.toFixed(2));

    const result = await buyContract(direction, stakeAmount);

    if (!result?.contractId) {
      stopBot('Bot stopped because the purchase failed.');
      return;
    }

    handledContractIdsRef.current.add(result.contractId);
    setLastContractId(result.contractId);
    setStatus('waiting');
    setMessage(`Waiting for contract #${result.contractId} to finish...`);
  }, [buyContract, direction, setStake, stopBot]);

  const startBot = useCallback(async () => {
    if (!canStart) {
      if (durationUnit !== 't') {
        toast.error('Bot needs tick duration', { description: 'Set duration unit to ticks before starting the bot.' });
      }
      return;
    }

    const baseStake = parsedSettings.baseStake;
    handledContractIdsRef.current = new Set();
    isRunningRef.current = true;
    setIsRunning(true);
    setStatus('idle');
    setTotalProfit(0);
    setCurrentStake(baseStake);
    currentStakeRef.current = baseStake;
    setLastContractId(null);
    setMessage('Bot started.');
    await placeTrade(baseStake);
  }, [canStart, durationUnit, parsedSettings.baseStake, placeTrade]);

  useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  useEffect(() => {
    if (!isRunning || !lastContractId) return;

    const timer = window.setInterval(() => {
      void refreshClosedPositions();
    }, 1200);

    return () => window.clearInterval(timer);
  }, [isRunning, lastContractId, refreshClosedPositions]);

  useEffect(() => {
    if (!isRunning || !lastContractId) return;

    const closed = closedPositions.find(position => Number(position.contract_id) === lastContractId);
    if (!closed) return;

    const profit = getPositionProfit(closed);
    const nextTotal = roundMoney(totalProfit + profit);
    const won = profit >= 0;

    setTotalProfit(nextTotal);
    setLastContractId(null);
    window.dispatchEvent(new CustomEvent('marketeye:refresh-accounts'));

    if (nextTotal >= parsedSettings.target) {
      stopBot(`Profit target reached: ${nextTotal.toFixed(2)} USD.`);
      return;
    }

    if (nextTotal <= -parsedSettings.loss) {
      stopBot(`Loss limit reached: ${nextTotal.toFixed(2)} USD.`);
      return;
    }

    const nextStake = won
      ? parsedSettings.baseStake
      : roundMoney(currentStakeRef.current * parsedSettings.size);

    if (nextStake > parsedSettings.max) {
      setMessage('Stake exceeded max stake, so it reset to the initial stake.');
      window.setTimeout(() => void placeTrade(parsedSettings.baseStake), 700);
      return;
    }

    setMessage(`${won ? 'Win' : 'Loss'}: ${profit.toFixed(2)} USD. Next stake: ${nextStake.toFixed(2)} USD.`);
    window.setTimeout(() => void placeTrade(nextStake), 700);
  }, [closedPositions, isRunning, lastContractId, parsedSettings, placeTrade, stopBot, totalProfit]);

  return (
    <div className="rounded-2xl border border-border bg-card shadow-sm">
      <button
        type="button"
        onClick={() => setIsOpen(value => !value)}
        className="flex w-full items-center justify-between px-4 py-3 text-left"
      >
        <div>
          <p className="text-sm font-bold">Bot</p>
          <p className="text-xs text-muted-foreground">
            {isRunning ? 'ON — Martingale running' : 'OFF — Martingale bot'}
          </p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-bold ${isRunning ? 'bg-emerald-500 text-white' : 'bg-muted text-muted-foreground'}`}>
          {isRunning ? 'ON' : 'OFF'}
        </span>
      </button>

      {isOpen && (
        <div className="max-h-[42dvh] space-y-3 overflow-y-auto border-t border-border p-3">
          <div className="rounded-xl border border-border bg-muted/20 p-3 text-xs text-muted-foreground">
            <p className="font-semibold text-foreground">Martingale 1.0</p>
            <p>Market: {activeSymbolName ?? 'Loading...'}</p>
            <p>Duration: {duration} {durationUnit === 't' ? 'tick(s)' : durationUnit}</p>
            <p>Status: {status}</p>
            <p className="mt-1 text-foreground">{message}</p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Direction</Label>
              <Select value={direction} onValueChange={(value) => setDirection(value as Direction)} disabled={isRunning}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="CALL">Rise</SelectItem>
                  <SelectItem value="PUT">Fall</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Initial stake</Label>
              <Input value={initialStake} onChange={e => setInitialStake(e.target.value)} type="number" min={0.01} step="0.01" disabled={isRunning} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Multiplier</Label>
              <Input value={multiplier} onChange={e => setMultiplier(e.target.value)} type="number" min={1.01} step="0.01" disabled={isRunning} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Max stake</Label>
              <Input value={maxStake} onChange={e => setMaxStake(e.target.value)} type="number" min={0.01} step="0.01" disabled={isRunning} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Profit target</Label>
              <Input value={profitTarget} onChange={e => setProfitTarget(e.target.value)} type="number" min={0.01} step="0.01" disabled={isRunning} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Loss limit</Label>
              <Input value={lossLimit} onChange={e => setLossLimit(e.target.value)} type="number" min={0.01} step="0.01" disabled={isRunning} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-muted/20 p-3 text-xs">
            <div>
              <p className="text-muted-foreground">Current stake</p>
              <p className="font-bold">{currentStake.toFixed(2)} USD</p>
            </div>
            <div>
              <p className="text-muted-foreground">Total profit</p>
              <p className="font-bold">{totalProfit.toFixed(2)} USD</p>
            </div>
          </div>

          {!isAuthenticated && <p className="text-xs text-destructive">Log in to Deriv before starting the bot.</p>}
          {durationUnit !== 't' && <p className="text-xs text-destructive">This Martingale bot needs tick duration. Select ticks in the trade controls.</p>}

          <div className="grid grid-cols-2 gap-2">
            <Button disabled={!canStart || isRunning} onClick={() => void startBot()} className="rounded-full font-bold">
              Start Bot
            </Button>
            <Button variant="destructive" disabled={!isRunning} onClick={() => stopBot('Bot stopped manually.')} className="rounded-full font-bold">
              Stop Bot
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
